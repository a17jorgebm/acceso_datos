package com.pepinho.files;


import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.Date;

import static java.lang.System.*;

public class Exercicio1 {

    public static void main(String[] args) {

        long time = System.currentTimeMillis();
        StringBuilder numero = new StringBuilder("catro");
        for (int i = 0; i < 90000; i++) {
            numero.append(i);
        }
        out.println(System.currentTimeMillis() - time);

//        System.exit(0);


        JFileChooser fc = new JFileChooser("c:\\");
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            File arquivo = fc.getSelectedFile();
            StringBuilder sb = new StringBuilder();
            sb.append("Ruta absoluta: ")
                    .append(System.lineSeparator());
            sb.append(arquivo.getAbsolutePath())
                    .append(System.lineSeparator());
            sb.append("Ruta absoluta: ")
                    .append(System.lineSeparator());
            sb.append(arquivo.getAbsolutePath())
                    .append(System.lineSeparator());
            sb.append("Nome arquivo: ")
                    .append(System.lineSeparator());
            sb.append(arquivo.getName())
                    .append(System.lineSeparator());
            sb.append("Tamaño: ")
                    .append(arquivo.length()).append(" bytes").append(System.lineSeparator());
            sb.append("Data modificación: ");
            sb.append(new Date(arquivo.lastModified()))
                    .append(System.lineSeparator());
            sb.append((arquivo.isFile() ? "Es un archivo" : "Es un directorio"));

            JOptionPane.showMessageDialog(null, sb.toString());
        }


//        File arquivo = new File("pom.xml");
//        if(arquivo.exists()){
//            out.println("Existe");
//            out.println("Ruta absoluta: " + arquivo.getAbsolutePath());
//            out.println("Nome arquivo: " + arquivo.getName());
//            out.println("Tamaño: " + arquivo.length() + " bytes");
//            out.println("Data modificación: " + new Date(arquivo.lastModified()));
//            out.println(arquivo.isFile() ? "Es un archivo" : "Es un directorio");
//        } else {
//            out.println("Non existe");
//            try {
//                if(arquivo.createNewFile())
//                    out.println("archivo creado");
//                else
//                    out.println("Error al crear el archivo");
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//        }

//        out.println(arquivo.exists() ? "Existe" : "Non existe");
    }

}
