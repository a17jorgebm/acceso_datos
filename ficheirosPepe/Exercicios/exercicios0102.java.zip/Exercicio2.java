package com.pepinho.files;

/*


Debes trabajar únicamente con métodos de la clase File.

El programa abre una ventana para la selección de un directorio (hazlo también desde teclado si recoge un parámetro) y
usando el método listFiles() de la clase File, muestra el contenido de ese directorio, indicando el tamaño de los
archivos y si es un directorio o no. Además, muestra el tamaño total de los archivos y directorios.

Muestra en una ventana emergente el resultado y por consola.

 */

import javax.swing.*;
import java.io.File;

public class Exercicio2 {

    public static String toMbKbBytes(long bytes) {
        long kb = bytes / 1024;
        long mb = kb / 1024;
        long remainingKb = kb % 1024;
        long remainingBytes = bytes % 1024;
        return mb + " MB, " + remainingKb + " KB, " + remainingBytes + " bytes";
    }

    public static void main(String[] args) {
        JFileChooser fc = new JFileChooser("c:\\");
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        if (args.length > 0) {
            fc.setCurrentDirectory(new File(args[0]));
        }

        if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            File[] files = fc.getSelectedFile().listFiles();
            long totalSize = 0;
            StringBuilder sb = new StringBuilder();
            for (File file : files) {
                long size = 0;
                if (file.isHidden()) {
                    continue;
                }
                if (file.isDirectory()) {
                    File[] subFiles = file.listFiles();
                    if (subFiles != null)
                        for (File subFile : subFiles) {
                            if (subFile.isFile())
                                size += subFile.length();
                        }
                } else {
                    size = file.length();
                }
                totalSize += size;
                sb.append(file.getName())
                        .append(" - ")
                        .append(toMbKbBytes(size))
                        .append(" bytes - ")
                        .append(file.isDirectory() ? "Directorio" : "Archivo")
                        .append(System.lineSeparator());
            }

            sb.append("Tamaño total: ")
                    .append(toMbKbBytes(totalSize))
                    .append(" bytes")
                    .append(System.lineSeparator());

            System.out.println(sb.toString());
            
            JOptionPane.showMessageDialog(null, sb.toString());



        }

    }
}
